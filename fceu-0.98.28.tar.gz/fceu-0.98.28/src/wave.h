void FCEU_WriteWaveData(int32 *Buffer, int Count);

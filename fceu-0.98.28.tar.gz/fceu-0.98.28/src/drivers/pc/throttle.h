void RefreshThrottleFPS(void);
void SpeedThrottle(void);

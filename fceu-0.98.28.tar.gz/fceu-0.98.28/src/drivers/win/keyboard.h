void KeyboardClose(void);
int KeyboardInitialize(void);
void KeyboardUpdate(void);
unsigned char *GetKeyboard(void);
unsigned char *GetKeyboard_nr(void);
unsigned char *GetKeyboard_jd(void);
int KeyboardSetBackgroundAccess(int on);

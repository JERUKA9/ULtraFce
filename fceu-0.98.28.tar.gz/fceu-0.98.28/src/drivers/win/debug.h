#ifdef FCEUDEF_DEBUGGER
void KillDebugger(void);
void UpdateDebugger(void);
void BeginDSeq(HWND hParent);
void DoMemmo(HWND hParent);
#endif

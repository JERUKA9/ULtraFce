void UpdateMemWatch();
void CreateMemWatch();
void AddMemWatch();
extern char * MemWatchDir;

extern int PPUViewScanline;
extern int PPUViewer;
extern int scanline;

void UpdatePPUView(int refreshchr);


#!/bin/sh

aclocal
autoconf
automake -a -c --foreign

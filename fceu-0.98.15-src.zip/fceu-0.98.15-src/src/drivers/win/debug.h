#ifdef FCEUDEF_DEBUGGER
void KillDebugger(void);
void UpdateDebugger(void);
void BeginDSeq(HWND hParent);
#endif

void hq2x_32(unsigned char * pIn, unsigned char * pOut, int Xres, int Yres, int BpL);
int hq2x_InitLUTs(void);
void hq2x_Kill(void);


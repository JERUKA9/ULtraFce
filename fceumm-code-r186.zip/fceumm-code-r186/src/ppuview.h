extern int PPUViewScanline;
extern int PPUViewer;
extern int scanline;

void PPUViewDoBlit();
void DoPPUView();
void UpdatePPUView(int refreshchr);

